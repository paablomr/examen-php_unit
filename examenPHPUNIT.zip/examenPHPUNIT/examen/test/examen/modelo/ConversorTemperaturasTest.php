<?php

namespace examen\modelo;


class ConversorTemperaturasTest extends \PHPUnit\Framework\TestCase
{

    public function testFarenheitToCelsius()
    {
        $conversor = new ConversorTemperaturas();

        //prueba1
        $P0fTo1777c = $conversor->FarenheitToCelsius(0);
        $this->assertEquals(-17.78,floor($P0fTo1777c*100)/100);

        //prueba2
        $P200fTo9333c = $conversor->FarenheitToCelsius(200);
        $this->assertEquals(93.33,floor($P200fTo9333c * 100)/100);

        //prueba3
        $P600fTo315 = $conversor->FarenheitToCelsius(600);
        $this->assertEquals(315.55555555556,$P600fTo315 );

        //prueba4
        $P932fTo500 = $conversor->FarenheitToCelsius(932);
        $this->assertEquals(500,$P932fTo500);

    }

    public function testCelsiusToFarenheit()
    {
        $conversor = new ConversorTemperaturas();

        //prueba1
        $P0cTo32F = $conversor->CelsiusToFarenheit(0);
        $this->assertEquals(32,$P0cTo32F);

        //prueba2
        $P50cTo122F = $conversor->CelsiusToFarenheit(50);
        $this->assertEquals(122,$P50cTo122F);

        //prueba3
        $P500cTo932F = $conversor->CelsiusToFarenheit(500);
        $this->assertEquals(932,$P500cTo932F);

        //prueba4
        $P501cToError = $conversor->CelsiusToFarenheit(501);
        $this->assertEquals(PHP_FLOAT_MAX,$P501cToError);
    }
}
