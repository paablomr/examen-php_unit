<?php


namespace examen\modelo;


class ConversorTemperaturas
{
    public function CelsiusToFarenheit($Celsius){

        if($Celsius > 500)
            return PHP_FLOAT_MAX;
        else
            return ($Celsius * 9/5) + 32;
    }

    public function FarenheitToCelsius($Farenheit){

        return ($Farenheit - 32) * 5/9;
    }

}