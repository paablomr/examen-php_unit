<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Index examen</title>
</head>
<body>
<?php
use examen\modelo\ConversorTemperaturas;
require "vendor/autoload.php";

$calculadoraPotencias = new ConversorTemperaturas();
echo "0 Celsius a Farenhait: ";
print $calculadoraPotencias->CelsiusToFarenheit(0);
echo "</br>";
echo "50 Celsius a Farenhait: ";
print $calculadoraPotencias->CelsiusToFarenheit(50);
echo "</br>";
echo "500 Celsius a Farenhait: ";
print $calculadoraPotencias->CelsiusToFarenheit(500);
echo "</br>";
echo "501 Celsius a Farenhait: ";
print $calculadoraPotencias->CelsiusToFarenheit(501);
echo "</br>";
echo "</br>";
echo "0 Farenhait a Celsius: ";
print $calculadoraPotencias->FarenheitToCelsius(0);
echo "</br>";
echo "200 Farenhait a Celsius: ";
print $calculadoraPotencias->FarenheitToCelsius(200);
echo "</br>";
echo "600 Farenhait a Celsius: ";
print $calculadoraPotencias->FarenheitToCelsius(600);
echo "</br>";
echo "932 Farenhait a Celsius: ";
print $calculadoraPotencias->FarenheitToCelsius(932);
echo "</br>";
?>
</body>
</html>

<?php